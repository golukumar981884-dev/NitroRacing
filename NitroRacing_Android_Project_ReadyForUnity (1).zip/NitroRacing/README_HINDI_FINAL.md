# NITRO RACING — Unity 6 Android project foundation

यह ZIP पहले दिए गए Nitro Racing source, Milestone 3 greybox scene builder और 50-car fictional data catalog को एक Unity project structure में जोड़ता है। यह अभी final commercial-quality game नहीं है।

## शामिल
- Unity 6 project skeleton और URP/UGUI package manifest
- 4-wheel vehicle physics, steering, braking, drift, nitro और chase camera scripts
- 3 AI opponents, waypoint circuit, 2-lap race, countdown, ranking और finish HUD
- Touch hold controls और keyboard test controls
- Editor menu से greybox 3D demo scene बनाने का builder
- 50 original fictional car definitions; ये अभी 50 अलग 3D car models नहीं हैं
- Save data capacity 50 cars तक और backup-based save writing
- Android ARM64 IL2CPP APK build menu script

## Unity में आगे क्या करना है
1. Unity Hub में Unity **6000.0.40f1** install करें। Modules: Android Build Support, Android SDK & NDK Tools, OpenJDK.
2. इस folder को Unity Hub में Add करके खोलें; Package Manager dependencies resolve होने दें।
3. Unity menu: `Nitro Racing > Build Playable Demo Scene` (menu path को README से मिलाने के लिए ठीक किया गया है).
4. Console में कोई compile error हो तो उसे ठीक किए बिना build न करें। Scene `Assets/Scenes/NitroRacing_Demo.unity` में बनेगी।
5. Play Mode में driving, AI, wheel contact, checkpoints और touch UI test करें।
6. `Nitro Racing > Build Android APK` चुनें। APK `Builds/Android/NitroRacing.apk` में बनेगा।

## ईमानदार स्थिति
इस environment में Unity Editor/Android toolchain उपलब्ध नहीं था। इसलिए इस ZIP को Unity में खोलकर compile, Play Mode, device test या APK build नहीं किया गया है। Build menu script केवल Unity Editor के अंदर build चलाता है; यह अपने-आप APK नहीं बनाता।

इसमें अभी placeholder primitive cars/track हैं। Asphalt-जैसी final graphics के लिए original/licensed 3D car models, detailed track art, textures, VFX, audio, menus/garage, progression, optimization और असली Android device profiling अभी बाकी हैं।


## इस पैकेज में की गई जाँच/सुधार
- सभी C# फाइलों के braces और project folder structure की basic static जाँच की गई।
- Demo Scene Builder का Unity menu path ठीक किया गया ताकि वह `Nitro Racing` menu में दिखाई दे।
- यह static inspection है; Unity compilation या device test का विकल्प नहीं।

## मोबाइल से APK बनाने की सीमा
Android फोन पर Termux में Java/Gradle install होना Unity C# project को APK में compile नहीं करता। APK के लिए Unity 6 Editor और Android Build Support (SDK/NDK/OpenJDK) चाहिए। इस ZIP में APK शामिल नहीं है।
