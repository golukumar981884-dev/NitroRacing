# Nitro Racing — Milestone 3 (Playable Greybox Demo Builder)

## इस पैकेज में क्या है
- पहले Milestone के वाहन, Nitro, AI, Race, HUD और Save सिस्टम के अपडेटेड C# scripts
- `Assets/Editor/NitroDemoBuilder.cs` — Unity Editor में टेस्टिंग के लिए greybox 3D track, 1 player car, 3 AI cars, camera और mobile HUD बनाने वाला editor tool
- Demo scene को अपने-आप बनाने का menu command

> **महत्वपूर्ण सीमा:** यह अभी final/finished game या APK नहीं है। इस पैकेज में placeholder geometry (primitive 3D cars/track) है। Unity Editor उपलब्ध न होने के कारण इस वातावरण में Unity compilation, scene execution और Android build run नहीं किए जा सके।

## Unity में चलाने का तरीका
1. Unity Hub में **Unity 6 (6000.x)** का नया 3D project बनाएँ।
2. Package के अंदर का `NitroRacing/Assets` folder अपने Unity project के `Assets` folder में merge/copy करें।
3. Package Manager में **Unity UI (UGUI)** उपलब्ध/installed रखें।
4. `Edit > Project Settings > Player > Other Settings > Active Input Handling` को **Both** करें (keyboard/editor testing और legacy input axes के लिए)। Unity restart माँगे तो restart करें।
5. Unity के top menu में `NitroRacing > Build Playable Demo Scene` चुनें।
6. Builder scene और materials बनाएगा। फिर `Assets/Scenes/NitroRacing_Demo.unity` खोलकर Play दबाएँ।

## Controls
- Keyboard: A/D या Left/Right arrow से steer; Space brake; Left Shift nitro; Left Ctrl drift.
- Mobile: LEFT / RIGHT, BRAKE, NITRO, DRIFT on-screen hold buttons. Acceleration default में automatic है.

## इस milestone में क्या शामिल नहीं है
- Final licensed car models, detailed track art, menus/garage, audio, monetization, multiple tracks
- Device-specific performance profiling और Play Store-ready signed APK
- Unity Editor द्वारा compile/play-mode validation

## अगला validation checklist
- Unity Console में compile errors/warnings देखें
- सभी चार WheelColliders जमीन को ठीक से छू रहे हैं या नहीं
- AI waypoint follow, lap counting, finish state और respawn को Play Mode में जाँचें
- Android device पर touch multi-input, frame rate, heat और memory test करें

## Compatibility note
Scripts Unity 6 Rigidbody `linearVelocity` API का उपयोग करते हैं। Unity 2022 LTS पर चलाने से पहले `linearVelocity` को `velocity` से बदलना होगा।
