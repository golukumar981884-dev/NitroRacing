#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace NitroRacing.EditorTools {
    public static class NitroDemoBuilder {
        const string Root = "Assets/NitroRacingGenerated";
        static Material roadMat, grassMat, barrierMat, playerMat, redMat, blueMat, yellowMat, tireMat, glassMat, uiMat;

        [MenuItem("Nitro Racing/Build Playable Demo Scene")]
        public static void Build() {
            EnsureFolders(); CreateMaterials();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            scene.name = "NitroRacing_Demo";
            BuildEnvironment();
            var path = BuildTrack();
            var stats = CreateStats();
            var racers = new List<RacerProgress>();
            ArcadeVehicle playerCar = CreateCar("PLAYER", new Vector3(-51f, 0.45f, -29f), Quaternion.LookRotation(Vector3.right), playerMat, stats, true, path, racers, 0);
            CreateCar("AI - RED", new Vector3(-61f, 0.45f, -25f), Quaternion.LookRotation(Vector3.right), redMat, stats, false, path, racers, 1);
            CreateCar("AI - BLUE", new Vector3(-69f, 0.45f, -29f), Quaternion.LookRotation(Vector3.right), blueMat, stats, false, path, racers, 2);
            CreateCar("AI - YELLOW", new Vector3(-77f, 0.45f, -25f), Quaternion.LookRotation(Vector3.right), yellowMat, stats, false, path, racers, 3);
            var raceObj = new GameObject("Race Manager");
            var manager = raceObj.AddComponent<RaceManager>(); manager.player = racers[0]; manager.racers = racers; manager.countdownSeconds = 3;
            BuildCamera(playerCar); BuildHUD(manager, playerCar);
            AddLighting();
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/Scenes/NitroRacing_Demo.unity", true) };
            EditorSceneManager.SaveScene(scene, "Assets/Scenes/NitroRacing_Demo.unity");
            AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("Nitro Racing", "Playable greybox demo scene created. Open Assets/Scenes/NitroRacing_Demo.unity and press Play.\n\nNote: Unity compilation and gameplay still need to be tested on your machine.", "OK");
        }

        static void EnsureFolders() {
            if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "NitroRacingGenerated");
            if (!AssetDatabase.IsValidFolder(Root + "/Materials")) AssetDatabase.CreateFolder(Root, "Materials");
            if (!AssetDatabase.IsValidFolder(Root + "/Stats")) AssetDatabase.CreateFolder(Root, "Stats");
        }
        static Material MakeMat(string name, Color color, float metallic = 0f, float smooth = 0.35f) {
            var shader = Shader.Find("Universal Render Pipeline/Lit"); if (!shader) shader = Shader.Find("Standard");
            var m = new Material(shader); m.name = name; m.color = color;
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smooth);
            AssetDatabase.CreateAsset(m, Root + "/Materials/" + name + ".mat"); return m;
        }
        static void CreateMaterials() {
            roadMat = MakeMat("Road_Asphalt", new Color(.12f,.14f,.17f), .05f, .25f);
            grassMat = MakeMat("Grass", new Color(.12f,.28f,.16f)); barrierMat = MakeMat("Barrier_White", new Color(.82f,.84f,.86f), .1f,.5f);
            playerMat = MakeMat("Car_Nitro_Cyan", new Color(.02f,.75f,.95f), .65f,.8f);
            redMat = MakeMat("Car_Red", new Color(.9f,.08f,.06f), .55f,.7f); blueMat = MakeMat("Car_Blue", new Color(.12f,.25f,.95f), .55f,.7f);
            yellowMat = MakeMat("Car_Yellow", new Color(1f,.65f,.03f), .45f,.7f); tireMat = MakeMat("Tire_Rubber", new Color(.025f,.03f,.035f));
            glassMat = MakeMat("Window_Glass", new Color(.025f,.09f,.13f), .25f,.85f); uiMat = MakeMat("UI_Accent", new Color(.02f,.75f,.95f));
        }
        static void BuildEnvironment() {
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane); ground.name = "Grass Ground"; ground.transform.position = new Vector3(0,-.4f,0); ground.transform.localScale = new Vector3(25,1,18); ground.GetComponent<Renderer>().sharedMaterial = grassMat;
            var sun = new GameObject("Sun"); var light = sun.AddComponent<Light>(); light.type = LightType.Directional; light.intensity = 1.25f; sun.transform.rotation = Quaternion.Euler(48,-32,0);
            RenderSettings.ambientLight = new Color(.48f,.5f,.55f); RenderSettings.fog = true; RenderSettings.fogColor = new Color(.55f,.65f,.72f); RenderSettings.fogMode = FogMode.Exponential; RenderSettings.fogDensity = .0025f;
        }
        static WaypointPath BuildTrack() {
            Vector3[] pts = { new Vector3(-40,.15f,-25), new Vector3(40,.15f,-25), new Vector3(55,.15f,0), new Vector3(40,.15f,25), new Vector3(-40,.15f,25), new Vector3(-55,.15f,0) };
            var track = new GameObject("TRACK - Loop Circuit"); var path = track.AddComponent<WaypointPath>();
            path.points = new Transform[pts.Length];
            for (int i=0;i<pts.Length;i++) { var p = new GameObject("Waypoint_"+(i+1)); p.transform.SetParent(track.transform); p.transform.position=pts[i]; path.points[i]=p.transform; }
            for (int i=0;i<pts.Length;i++) {
                Vector3 a=pts[i], b=pts[(i+1)%pts.Length], d=b-a; float len=d.magnitude; Quaternion rot=Quaternion.LookRotation(d.normalized,Vector3.up);
                var road=GameObject.CreatePrimitive(PrimitiveType.Cube); road.name="Road Segment "+(i+1); road.transform.SetPositionAndRotation((a+b)*.5f+Vector3.down*.18f,rot); road.transform.localScale=new Vector3(18,.35f,len+2f); road.GetComponent<Renderer>().sharedMaterial=roadMat;
                for(int side=-1;side<=1;side+=2) { var rail=GameObject.CreatePrimitive(PrimitiveType.Cube); rail.name="Safety Barrier"; rail.transform.SetPositionAndRotation((a+b)*.5f+rot*new Vector3(side*9f,.65f,0),rot); rail.transform.localScale=new Vector3(.55f,1.3f,len); rail.GetComponent<Renderer>().sharedMaterial=barrierMat; }
                // Simple dashed center line segments
                int dashes=Mathf.Max(1,Mathf.FloorToInt(len/7f)); for(int k=0;k<dashes;k++){var dash=GameObject.CreatePrimitive(PrimitiveType.Cube); dash.name="Track Marking"; dash.transform.SetPositionAndRotation(Vector3.Lerp(a,b,(k+.5f)/dashes)+Vector3.up*.012f,rot); dash.transform.localScale=new Vector3(.22f,.025f,2.4f); dash.GetComponent<Renderer>().sharedMaterial=barrierMat; Object.DestroyImmediate(dash.GetComponent<Collider>());}
            }
            return path;
        }
        static VehicleStats CreateStats() {
            var s=ScriptableObject.CreateInstance<VehicleStats>(); s.displayName="Nitro Prototype"; s.motorTorque=2600; s.topSpeedKmh=230; s.maxSteerAngle=31; s.brakeTorque=5200; s.downforce=5.5f;
            AssetDatabase.CreateAsset(s,Root+"/Stats/NitroPrototype.asset"); return s;
        }
        static ArcadeVehicle CreateCar(string name, Vector3 pos, Quaternion rot, Material bodyMat, VehicleStats stats, bool player, WaypointPath path, List<RacerProgress> racers, int index) {
            var root=new GameObject(name); root.transform.SetPositionAndRotation(pos,rot);
            var rb=root.AddComponent<Rigidbody>(); rb.mass=1400; rb.drag=.02f; rb.angularDrag=.5f; rb.interpolation=RigidbodyInterpolation.Interpolate; rb.collisionDetectionMode=CollisionDetectionMode.ContinuousDynamic;
            var body=GameObject.CreatePrimitive(PrimitiveType.Cube); body.name="Body"; body.transform.SetParent(root.transform,false); body.transform.localPosition=new Vector3(0,.62f,0); body.transform.localScale=new Vector3(1.9f,.58f,4.2f); body.GetComponent<Renderer>().sharedMaterial=bodyMat; body.GetComponent<Collider>().material=new PhysicMaterial("Car Body") { dynamicFriction=.35f,staticFriction=.4f,bounciness=.05f };
            var cabin=GameObject.CreatePrimitive(PrimitiveType.Cube); cabin.name="Cabin"; cabin.transform.SetParent(root.transform,false); cabin.transform.localPosition=new Vector3(0,1.08f,-.25f); cabin.transform.localScale=new Vector3(1.45f,.62f,1.9f); cabin.GetComponent<Renderer>().sharedMaterial=glassMat; Object.DestroyImmediate(cabin.GetComponent<Collider>());
            var col=root.AddComponent<BoxCollider>(); col.center=new Vector3(0,.7f,0); col.size=new Vector3(1.9f,.75f,4.2f);
            WheelCollider fl=Wheel(root,"Wheel_FL",new Vector3(-.95f,.35f,1.35f)), fr=Wheel(root,"Wheel_FR",new Vector3(.95f,.35f,1.35f)), rl=Wheel(root,"Wheel_RL",new Vector3(-.95f,.35f,-1.35f)), rr=Wheel(root,"Wheel_RR",new Vector3(.95f,.35f,-1.35f));
            ArcadeVehicle car=root.AddComponent<ArcadeVehicle>(); car.stats=stats; car.fl=fl;car.fr=fr;car.rl=rl;car.rr=rr;
            root.AddComponent<NitroSystem>();
            var progress=root.AddComponent<RacerProgress>(); progress.car=car;progress.path=path;progress.racerName=name;progress.isPlayer=player;progress.totalLaps=2;progress.checkpointRadius=13f;
            if(player) { var pc=root.AddComponent<PlayerController>(); pc.autoAccelerate=true; }
            else { var ai=root.AddComponent<AIDriver>(); ai.difficulty=index==1?AIDriver.Difficulty.Easy:index==2?AIDriver.Difficulty.Medium:AIDriver.Difficulty.Hard; }
            racers.Add(progress); return car;
        }
        static WheelCollider Wheel(GameObject root,string name,Vector3 pos) {
            var wObj=new GameObject(name); wObj.transform.SetParent(root.transform,false); wObj.transform.localPosition=pos;
            var w=wObj.AddComponent<WheelCollider>(); w.radius=.38f;w.mass=25;w.suspensionDistance=.2f;w.wheelDampingRate=1.5f;
            JointSpring spring=w.suspensionSpring; spring.spring=35000;spring.damper=4500;spring.targetPosition=.5f;w.suspensionSpring=spring;
            WheelFrictionCurve f=w.forwardFriction;f.stiffness=1.35f;w.forwardFriction=f; WheelFrictionCurve s=w.sidewaysFriction;s.stiffness=1.5f;w.sidewaysFriction=s;
            var visual=GameObject.CreatePrimitive(PrimitiveType.Cylinder); visual.name=name+"_Visual";visual.transform.SetParent(root.transform,false);visual.transform.localPosition=pos;visual.transform.localRotation=Quaternion.Euler(0,0,90);visual.transform.localScale=new Vector3(.72f,.22f,.72f);visual.GetComponent<Renderer>().sharedMaterial=tireMat;Object.DestroyImmediate(visual.GetComponent<Collider>());
            return w;
        }
        static void BuildCamera(ArcadeVehicle car) {
            var camObj=Camera.main?Camera.main.gameObject:new GameObject("Main Camera"); camObj.tag="MainCamera"; var cam=camObj.GetComponent<Camera>(); if(!cam)cam=camObj.AddComponent<Camera>(); cam.nearClipPlane=.1f;cam.farClipPlane=700;cam.fieldOfView=65;
            var follow=camObj.GetComponent<ChaseCamera>();if(!follow)follow=camObj.AddComponent<ChaseCamera>();follow.target=car;camObj.transform.position=car.transform.position+new Vector3(0,5,-10);
            var audio=camObj.GetComponent<AudioListener>();if(!audio)camObj.AddComponent<AudioListener>();
        }
        static void BuildHUD(RaceManager race, ArcadeVehicle car) {
            var canvasObj=new GameObject("Race HUD",typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster)); var canvas=canvasObj.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;
            var scaler=canvasObj.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;scaler.referenceResolution=new Vector2(1920,1080);
            if(!Object.FindObjectOfType<EventSystem>())new GameObject("EventSystem",typeof(EventSystem),typeof(StandaloneInputModule));
            Text speed=Label(canvasObj.transform,"SPEED",new Vector2(.5f,.04f),new Vector2(.5f,.04f),new Vector2(0,25),42,TextAnchor.LowerCenter);
            Text pos=Label(canvasObj.transform,"POSITION",new Vector2(.03f,.93f),new Vector2(.03f,.93f),new Vector2(240,55),32,TextAnchor.MiddleLeft);
            Text timer=Label(canvasObj.transform,"TIMER",new Vector2(.97f,.93f),new Vector2(.97f,.93f),new Vector2(300,55),30,TextAnchor.MiddleRight);
            Text count=Label(canvasObj.transform,"COUNTDOWN",new Vector2(.5f,.62f),new Vector2(.5f,.62f),new Vector2(300,140),90,TextAnchor.MiddleCenter);
            Text prog=Label(canvasObj.transform,"PROGRESS",new Vector2(.5f,.97f),new Vector2(.5f,.97f),new Vector2(220,45),25,TextAnchor.UpperCenter);
            var barObj=new GameObject("Nitro Bar",typeof(RectTransform),typeof(Slider));barObj.transform.SetParent(canvasObj.transform,false);var br=barObj.GetComponent<RectTransform>();br.anchorMin=new Vector2(.5f,.12f);br.anchorMax=new Vector2(.5f,.12f);br.sizeDelta=new Vector2(360,26);br.anchoredPosition=Vector2.zero;
            var bg=ImageChild(barObj.transform,"Background",new Color(.02f,.04f,.06f,.8f));var fill=ImageChild(barObj.transform,"Fill",new Color(.0f,.8f,1f,1f));var slider=barObj.GetComponent<Slider>();slider.minValue=0;slider.maxValue=1;slider.fillRect=fill.rectTransform;slider.targetGraphic=fill;slider.interactable=false;slider.value=.5f;
            var resultPanel=new GameObject("Finish Panel",typeof(RectTransform),typeof(Image));resultPanel.transform.SetParent(canvasObj.transform,false);var rp=resultPanel.GetComponent<RectTransform>();rp.anchorMin=new Vector2(.5f,.5f);rp.anchorMax=new Vector2(.5f,.5f);rp.sizeDelta=new Vector2(650,300);resultPanel.GetComponent<Image>().color=new Color(.01f,.03f,.06f,.9f);
            var result=Label(resultPanel.transform,"RESULT",new Vector2(.5f,.5f),new Vector2(.5f,.5f),new Vector2(600,250),44,TextAnchor.MiddleCenter);
            var hud=canvasObj.AddComponent<RaceHUD>();hud.race=race;hud.car=car;hud.speed=speed;hud.position=pos;hud.timer=timer;hud.countdown=count;hud.progress=prog;hud.nitroBar=slider;hud.resultPanel=resultPanel;hud.result=result;
            // On-screen controls: steering left/right and optional brake/nitro/drift. Acceleration is automatic.
            var pc=car.GetComponent<PlayerController>();pc.left=MakeHold(canvasObj.transform,"LEFT",new Vector2(.08f,.16f),new Color(.08f,.12f,.18f,.7f));pc.right=MakeHold(canvasObj.transform,"RIGHT",new Vector2(.22f,.16f),new Color(.08f,.12f,.18f,.7f));pc.brake=MakeHold(canvasObj.transform,"BRAKE",new Vector2(.91f,.16f),new Color(.55f,.08f,.08f,.72f));pc.nitro=MakeHold(canvasObj.transform,"NITRO",new Vector2(.82f,.29f),new Color(.0f,.55f,.85f,.78f));pc.drift=MakeHold(canvasObj.transform,"DRIFT",new Vector2(.94f,.34f),new Color(.5f,.25f,.02f,.78f));
        }
        static Text Label(Transform parent,string name,Vector2 amin,Vector2 amax,Vector2 size,int font,TextAnchor align) {
            var go=new GameObject(name,typeof(RectTransform),typeof(CanvasRenderer),typeof(Text));go.transform.SetParent(parent,false);var r=go.GetComponent<RectTransform>();r.anchorMin=amin;r.anchorMax=amax;r.sizeDelta=size;r.anchoredPosition=Vector2.zero;
            var t=go.GetComponent<Text>();t.font=Resources.GetBuiltinResource<Font>("Arial.ttf");t.fontSize=font;t.alignment=align;t.color=Color.white;t.fontStyle=FontStyle.Bold;t.horizontalOverflow=HorizontalWrapMode.Overflow;t.verticalOverflow=VerticalWrapMode.Overflow;t.text=name;return t;
        }
        static Image ImageChild(Transform parent,string name,Color color) {var go=new GameObject(name,typeof(RectTransform),typeof(CanvasRenderer),typeof(Image));go.transform.SetParent(parent,false);var im=go.GetComponent<Image>();im.color=color;var r=go.GetComponent<RectTransform>();r.anchorMin=Vector2.zero;r.anchorMax=Vector2.one;r.offsetMin=Vector2.zero;r.offsetMax=Vector2.zero;return im;}
        static HoldButton MakeHold(Transform parent,string label,Vector2 anchor,Color color) {
            var go=new GameObject(label+" Button",typeof(RectTransform),typeof(CanvasRenderer),typeof(Image),typeof(HoldButton));go.transform.SetParent(parent,false);var r=go.GetComponent<RectTransform>();r.anchorMin=anchor;r.anchorMax=anchor;r.sizeDelta=new Vector2(150,115);r.anchoredPosition=Vector2.zero;
            var im=go.GetComponent<Image>();im.color=color;var t=Label(go.transform,label,Vector2.zero,Vector2.one,Vector2.zero,24,TextAnchor.MiddleCenter);t.raycastTarget=false;return go.GetComponent<HoldButton>();
        }
        static void AddLighting() { var cam=Camera.main;if(cam){cam.clearFlags=CameraClearFlags.Skybox;cam.backgroundColor=new Color(.45f,.65f,.85f);} }
    }
}
#endif
