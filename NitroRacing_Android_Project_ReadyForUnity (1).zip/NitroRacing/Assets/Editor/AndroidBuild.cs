#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace NitroRacing.EditorTools {
    public static class AndroidBuild {
        [MenuItem("Nitro Racing/Build Android APK")]
        public static void BuildApk() {
            const string scene = "Assets/Scenes/NitroRacing_Demo.unity";
            if (!File.Exists(scene)) {
                EditorUtility.DisplayDialog("Nitro Racing", "Demo scene missing. First run Nitro Racing > Build Playable Demo Scene.", "OK");
                return;
            }
            if (!EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android)) {
                Debug.LogError("Could not switch to Android build target. Install Android Build Support, SDK, NDK and OpenJDK in Unity Hub.");
                return;
            }
            EditorUserBuildSettings.buildAppBundle = false;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.nitroracing.mobile");
            PlayerSettings.productName = "Nitro Racing";
            string output = Path.GetFullPath("Builds/Android/NitroRacing.apk");
            Directory.CreateDirectory(Path.GetDirectoryName(output));
            var options = new BuildPlayerOptions {
                scenes = new[] { scene }, locationPathName = output,
                target = BuildTarget.Android, options = BuildOptions.None
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result == BuildResult.Succeeded)
                EditorUtility.DisplayDialog("Nitro Racing", "APK build succeeded:\n" + output, "OK");
            else Debug.LogError("Android build failed: " + report.summary.result + " - " + report.summary.totalErrors + " errors");
        }
    }
}
#endif
