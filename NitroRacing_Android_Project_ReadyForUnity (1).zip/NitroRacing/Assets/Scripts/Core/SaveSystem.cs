using System.IO;
using UnityEngine;
namespace NitroRacing {
    [System.Serializable] public class SaveData {
        public int version = 1; public int credits = 0;
        public int selectedCar = 0; public bool[] unlockedCars = new bool[50];
        public int[] upgrades = new int[50 * 4];
        public int graphicsPreset = 1, fpsLimit = 30; public bool tilt, autoAccel;
        public float musicVol = 0.8f, sfxVol = 1f;
        public SaveData() { unlockedCars[0] = true; }
    }
    /// <summary>Atomic write (tmp + move) with .bak recovery from corrupt/missing saves.</summary>
    public static class SaveSystem {
        static string FilePath => Path.Combine(Application.persistentDataPath, "save.json");
        public static SaveData Load() {
            foreach (var p in new[] { FilePath, FilePath + ".bak" }) {
                try {
                    if (File.Exists(p)) {
                        var d = JsonUtility.FromJson<SaveData>(File.ReadAllText(p));
                        if (d != null && d.unlockedCars != null && d.unlockedCars.Length == 50) return d;
                    }
                } catch (System.Exception e) { Debug.LogWarning($"Save read failed {p}: {e.Message}"); }
            }
            return new SaveData();
        }
        public static void Save(SaveData d) {
            try {
                string tmp = FilePath + ".tmp";
                File.WriteAllText(tmp, JsonUtility.ToJson(d));
                if (File.Exists(FilePath)) {
                    File.Copy(FilePath, FilePath + ".bak", true);
                    string swap = FilePath + ".swap";
                    File.Copy(tmp, swap, true);
                    File.Delete(FilePath);
                    File.Move(swap, FilePath);
                    File.Delete(tmp);
                } else { File.Move(tmp, FilePath); }
            } catch (System.Exception e) { Debug.LogError("Save failed: " + e.Message); }
        }
    }
}
