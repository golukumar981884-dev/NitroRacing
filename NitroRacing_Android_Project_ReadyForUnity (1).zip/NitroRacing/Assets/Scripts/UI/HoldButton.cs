using UnityEngine;
using UnityEngine.EventSystems;
namespace NitroRacing {
    /// <summary>Press-and-hold UI button (multi-touch friendly). Add to any UI Image.</summary>
    public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler {
        public bool Held { get; private set; }
        public void OnPointerDown(PointerEventData e) => Held = true;
        public void OnPointerUp(PointerEventData e) => Held = false;
        public void OnPointerExit(PointerEventData e) => Held = false;
        void OnDisable() => Held = false;
    }
}
