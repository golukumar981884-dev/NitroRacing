using UnityEngine;
using UnityEngine.UI;
namespace NitroRacing {
    public class RaceHUD : MonoBehaviour {
        public RaceManager race; public ArcadeVehicle car;
        public Text speed, position, timer, countdown, progress, result;
        public Slider nitroBar;
        public GameObject resultPanel;
        void Start() {
            if (!race || !car || !race.player || !speed || !position || !timer || !countdown || !progress || !nitroBar) {
                Debug.LogError("RaceHUD: assign race, car, player progress, all text fields and nitro slider.", this);
                enabled = false;
                return;
            }
            if (resultPanel) resultPanel.SetActive(false);
            race.OnRaceFinished += list => {
                if (resultPanel) resultPanel.SetActive(true);
                if (result) result.text = $"FINISHED  P{race.PlayerPosition}\n+{RaceManager.RewardForPosition(race.PlayerPosition)} credits";
            };
        }
        void Update() {
            if (!race || !car) return;
            speed.text = Mathf.RoundToInt(car.SpeedKmh) + " KM/H";
            nitroBar.value = car.Nitro.Normalized;
            position.text = $"{race.PlayerPosition}/{race.racers.Count}";
            timer.text = System.TimeSpan.FromSeconds(race.RaceTime).ToString(@"mm\:ss\.ff");
            progress.text = Mathf.RoundToInt(race.player.Percent * 100) + "%";
            countdown.text = race.CountdownValue > 0 ? race.CountdownValue.ToString()
                : (race.state == RaceManager.State.Racing && race.RaceTime < 1f ? "GO!" : "");
        }
    }
}
