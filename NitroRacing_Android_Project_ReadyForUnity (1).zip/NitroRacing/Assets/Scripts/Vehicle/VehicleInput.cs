using UnityEngine;
namespace NitroRacing {
    /// <summary>Shared input state. Player and AI both write into this.</summary>
    [System.Serializable]
    public class VehicleInput {
        [Range(0,1)] public float throttle;
        [Range(0,1)] public float brake;
        [Range(-1,1)] public float steer;
        public bool nitro;
        public bool drift;
    }
}
