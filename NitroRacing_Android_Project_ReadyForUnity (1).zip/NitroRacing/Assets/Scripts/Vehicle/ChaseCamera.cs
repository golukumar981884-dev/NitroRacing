using UnityEngine;
namespace NitroRacing {
    /// <summary>Speed/nitro/drift-aware chase camera with FOV kick and shake.</summary>
    [RequireComponent(typeof(Camera))]
    public class ChaseCamera : MonoBehaviour {
        public ArcadeVehicle target;
        public Vector3 offset = new Vector3(0, 2.2f, -6.0f);
        public Vector3 closeOffset = new Vector3(0, 1.4f, -4.0f);
        public bool closeMode;
        public float followLag = 6f, lookLag = 10f;
        public float baseFov = 60f, speedFov = 14f, nitroFov = 10f;
        public float shakeAtNitro = 0.04f;
        Camera cam; float fov; Vector3 smoothPos; bool init;

        void Awake() { cam = GetComponent<Camera>(); fov = baseFov; }

        void LateUpdate() {
            if (!target) return;
            var t = target.transform;
            Vector3 o = closeMode ? closeOffset : offset;
            Vector3 vel = target.Rb.linearVelocity;
            Vector3 dir = Vector3.Slerp(t.forward, vel.sqrMagnitude > 25f ? vel.normalized : t.forward, 0.35f);
            Quaternion heading = Quaternion.LookRotation(Vector3.ProjectOnPlane(dir, Vector3.up).normalized, Vector3.up);
            Vector3 desired = t.position + heading * o;
            smoothPos = init ? Vector3.Lerp(smoothPos, desired, followLag * Time.deltaTime) : desired;
            init = true;
            Vector3 shake = target.Nitro.Active ? Random.insideUnitSphere * shakeAtNitro : Vector3.zero;
            transform.position = smoothPos + shake;
            Quaternion look = Quaternion.LookRotation(t.position + Vector3.up - transform.position, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, look, lookLag * Time.deltaTime);

            float targetFov = baseFov + speedFov * Mathf.Clamp01(target.SpeedKmh / target.stats.TopSpeed)
                              + (target.Nitro.Active ? nitroFov : 0f);
            fov = Mathf.Lerp(fov, targetFov, 4f * Time.deltaTime);
            cam.fieldOfView = fov;
        }
    }
}
