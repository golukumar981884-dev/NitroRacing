using UnityEngine;
namespace NitroRacing {
    /// <summary>Per-car tuning. Create via Assets > Create > NitroRacing > Vehicle Stats.</summary>
    [CreateAssetMenu(menuName = "NitroRacing/Vehicle Stats")]
    public class VehicleStats : ScriptableObject {
        public string displayName = "Prototype";
        public enum CarClass { D, C, B, A, S }
        public CarClass carClass = CarClass.S;
        [Header("Base performance")]
        public float motorTorque = 2200f;
        public float topSpeedKmh = 300f;
        public float maxSteerAngle = 30f;
        public float steerAtSpeedFactor = 0.3f;
        public float brakeTorque = 4500f;
        public float downforce = 4f;
        [Header("Nitro")]
        public float nitroCapacity = 100f;
        public float nitroDrainPerSec = 25f;
        public float nitroRefillPerSec = 6f;
        public float nitroTorqueMultiplier = 1.8f;
        public float nitroTopSpeedMultiplier = 1.25f;
        [Header("Upgrade levels 0-5")]
        [Range(0,5)] public int accelLevel, speedLevel, handlingLevel, nitroLevel;
        public float Accel => motorTorque * (1f + 0.06f * accelLevel);
        public float TopSpeed => topSpeedKmh * (1f + 0.04f * speedLevel);
        public float Steer => maxSteerAngle * (1f + 0.05f * handlingLevel);
        public float NitroCap => nitroCapacity * (1f + 0.10f * nitroLevel);
    }
}
