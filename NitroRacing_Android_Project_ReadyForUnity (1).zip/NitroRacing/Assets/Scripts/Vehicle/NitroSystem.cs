using UnityEngine;
namespace NitroRacing {
    public class NitroSystem : MonoBehaviour {
        public VehicleStats stats;
        public ParticleSystem[] flames;
        public Light exhaustGlow;
        public float Amount { get; private set; }
        public bool Active { get; private set; }
        public float Normalized => stats && stats.NitroCap > 0f ? Mathf.Clamp01(Amount / stats.NitroCap) : 0f;
        public float TorqueMul => Active ? stats.nitroTorqueMultiplier : 1f;
        public float SpeedMul => Active ? stats.nitroTopSpeedMultiplier : 1f;

        public void Init(VehicleStats s) {
            stats = s;
            Amount = stats ? stats.NitroCap * 0.5f : 0f;
            if (!stats) Debug.LogError($"NitroSystem on {name}: VehicleStats is not assigned.", this);
        }

        public void Tick(bool wantNitro, float dt) {
            if (!stats) { if (Active) SetActive(false); return; }
            bool should = wantNitro && Amount > 0.5f;
            if (should) Amount = Mathf.Max(0, Amount - stats.nitroDrainPerSec * dt);
            else Amount = Mathf.Min(stats.NitroCap, Amount + stats.nitroRefillPerSec * dt);
            if (should != Active) SetActive(should);
        }
        public void Add(float v) { if (stats) Amount = Mathf.Min(stats.NitroCap, Amount + Mathf.Max(0f, v)); }

        void SetActive(bool a) {
            Active = a;
            foreach (var f in flames ?? System.Array.Empty<ParticleSystem>()) { if (!f) continue; if (a) f.Play(); else f.Stop(); }
            if (exhaustGlow) exhaustGlow.enabled = a;
        }
    }
}
