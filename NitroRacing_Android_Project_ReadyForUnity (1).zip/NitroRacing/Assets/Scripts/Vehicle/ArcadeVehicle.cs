using UnityEngine;
namespace NitroRacing {
    /// <summary>
    /// Arcade car on 4 WheelColliders: drive, brake, steer, drift, downforce,
    /// speed cap, nitro, air stunts. Unity 6 uses Rigidbody.linearVelocity;
    /// on 2022 LTS rename to .velocity.
    /// </summary>
    [RequireComponent(typeof(Rigidbody), typeof(NitroSystem))]
    public class ArcadeVehicle : MonoBehaviour {
        public VehicleStats stats;
        public VehicleInput input = new VehicleInput();
        public WheelCollider fl, fr, rl, rr;
        public Transform flMesh, frMesh, rlMesh, rrMesh;
        public Vector3 centerOfMassOffset = new Vector3(0, -0.45f, 0.1f);
        public float driftGripMultiplier = 0.55f;
        public float airSpinTorque = 6f;
        public bool controlsEnabled = true;

        public Rigidbody Rb { get; private set; }
        public NitroSystem Nitro { get; private set; }
        public float SpeedKmh => Rb.linearVelocity.magnitude * 3.6f;
        public bool Grounded { get; private set; }
        public bool Drifting { get; private set; }
        public float AirTime { get; private set; }
        public System.Action<float> OnLanded;

        WheelFrictionCurve rlSide0, rrSide0;

        void Awake() {
            Rb = GetComponent<Rigidbody>();
            Nitro = GetComponent<NitroSystem>();
            if (!stats) {
                Debug.LogError($"ArcadeVehicle on {name}: assign a VehicleStats asset.", this);
                enabled = false;
                return;
            }
            if (!fl || !fr || !rl || !rr) {
                Debug.LogError($"ArcadeVehicle on {name}: assign all four WheelColliders (fl/fr/rl/rr).", this);
                enabled = false;
                return;
            }
            Nitro.Init(stats);
            Rb.mass = 1400f;
            Rb.centerOfMass += centerOfMassOffset;
            Rb.interpolation = RigidbodyInterpolation.Interpolate;
            rlSide0 = rl.sidewaysFriction; rrSide0 = rr.sidewaysFriction;
        }

        void FixedUpdate() {
            if (!enabled || !Rb || !Nitro || !stats || !fl || !fr || !rl || !rr) return;
            var i = controlsEnabled ? input : new VehicleInput { brake = 1f };
            float dt = Time.fixedDeltaTime;
            Nitro.Tick(i.nitro && i.throttle > 0.1f && controlsEnabled, dt);

            Grounded = fl.isGrounded || fr.isGrounded || rl.isGrounded || rr.isGrounded;
            float speed = SpeedKmh;
            float cap = stats.TopSpeed * Nitro.SpeedMul;

            float falloff = Mathf.Clamp01(1f - speed / cap);
            float torque = i.throttle * stats.Accel * Nitro.TorqueMul * Mathf.Max(0.15f, falloff);
            rl.motorTorque = rr.motorTorque = Grounded ? torque : 0f;

            float b = i.brake * stats.brakeTorque;
            fl.brakeTorque = fr.brakeTorque = b; rl.brakeTorque = rr.brakeTorque = b * 0.8f;
            if (i.throttle < 0.05f && i.brake < 0.05f) rl.brakeTorque = rr.brakeTorque = 200f;

            float steerAmt = Mathf.Lerp(stats.Steer, stats.Steer * stats.steerAtSpeedFactor, speed / cap);
            float target = i.steer * steerAmt;
            fl.steerAngle = fr.steerAngle = Mathf.Lerp(fl.steerAngle, target, 12f * dt);

            Drifting = i.drift && speed > 60f && Mathf.Abs(i.steer) > 0.2f && Grounded;
            SetRearGrip(Drifting ? driftGripMultiplier : 1f);
            if (Drifting) {
                Rb.AddTorque(transform.up * i.steer * 2.5f, ForceMode.Acceleration);
                Nitro.Add(6f * dt);
            }

            Rb.AddForce(-transform.up * Rb.linearVelocity.magnitude * stats.downforce);
            if (speed > cap * 1.02f)
                Rb.linearVelocity = Rb.linearVelocity.normalized * (cap / 3.6f);

            // Air stunts: steer = flat spin, brake = barrel roll
            if (!Grounded) {
                AirTime += dt;
                Rb.AddTorque(transform.up * i.steer * airSpinTorque, ForceMode.Acceleration);
                Rb.AddTorque(transform.forward * -i.brake * airSpinTorque, ForceMode.Acceleration);
            } else if (AirTime > 0f) {
                if (AirTime > 0.6f) { Nitro.Add(AirTime * 8f); OnLanded?.Invoke(AirTime); }
                AirTime = 0f;
            }
        }

        void SetRearGrip(float m) {
            var a = rlSide0; a.stiffness = rlSide0.stiffness * m; rl.sidewaysFriction = a;
            var c = rrSide0; c.stiffness = rrSide0.stiffness * m; rr.sidewaysFriction = c;
        }

        void Update() { SyncWheel(fl, flMesh); SyncWheel(fr, frMesh); SyncWheel(rl, rlMesh); SyncWheel(rr, rrMesh); }
        static void SyncWheel(WheelCollider c, Transform m) {
            if (!c || !m) return;
            c.GetWorldPose(out var p, out var q); m.SetPositionAndRotation(p, q);
        }

        public void Respawn(Vector3 pos, Quaternion rot) {
            if (!Rb) return;
            Rb.linearVelocity = Vector3.zero; Rb.angularVelocity = Vector3.zero;
            transform.SetPositionAndRotation(pos + Vector3.up, rot);
        }
    }
}
