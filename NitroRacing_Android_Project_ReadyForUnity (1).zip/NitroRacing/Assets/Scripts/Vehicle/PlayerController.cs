using UnityEngine;
namespace NitroRacing {
    /// <summary>
    /// Touch + tilt + keyboard (editor) input. Requires Active Input Handling = "Both".
    /// </summary>
    [RequireComponent(typeof(ArcadeVehicle))]
    public class PlayerController : MonoBehaviour {
        public HoldButton left, right, accelerate, brake, nitro, drift;
        public bool useTilt;
        public bool autoAccelerate;
        public float sensitivity = 1f;
        public float tiltRange = 0.35f;
        ArcadeVehicle car;
        float steerSmooth;

        void Awake() { car = GetComponent<ArcadeVehicle>(); }

        void Update() {
            var i = car.input;
            float s = 0;
            if (useTilt) s = Mathf.Clamp(Input.acceleration.x / tiltRange, -1f, 1f);
            else {
                if (left && left.Held) s -= 1;
                if (right && right.Held) s += 1;
                s += Input.GetAxisRaw("Horizontal");
            }
            steerSmooth = Mathf.MoveTowards(steerSmooth, Mathf.Clamp(s * sensitivity, -1, 1), 6f * Time.deltaTime);
            i.steer = steerSmooth;
            bool acc = autoAccelerate || (accelerate && accelerate.Held) || Input.GetKey(KeyCode.W);
            i.throttle = acc ? 1f : 0f;
            i.brake = ((brake && brake.Held) || Input.GetKey(KeyCode.S)) ? 1f : 0f;
            i.nitro = (nitro && nitro.Held) || Input.GetKey(KeyCode.Space);
            i.drift = (drift && drift.Held) || Input.GetKey(KeyCode.LeftShift);
        }
    }
}
