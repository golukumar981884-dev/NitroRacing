using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace NitroRacing {
    /// <summary>Countdown, race clock, ranking, finish, stuck respawn. Classic/Quick Race.</summary>
    public class RaceManager : MonoBehaviour {
        public List<RacerProgress> racers = new List<RacerProgress>();
        public RacerProgress player;
        public int countdownSeconds = 3;
        public float resetIfStuckSeconds = 4f;
        public enum State { Waiting, Countdown, Racing, Finished }
        public State state { get; private set; } = State.Waiting;
        public float RaceTime { get; private set; }
        public int PlayerPosition { get; private set; } = 1;
        public int CountdownValue { get; private set; }
        public System.Action<List<RacerProgress>> OnRaceFinished;
        readonly Dictionary<RacerProgress, float> stuck = new Dictionary<RacerProgress, float>();

        void Start() {
            racers.RemoveAll(r => !r || !r.enabled || !r.car || !r.path || !r.path.IsValid);
            if (!player || !racers.Contains(player) || racers.Count < 2) {
                Debug.LogError("RaceManager: assign the player and at least one valid opponent in the racers list.", this);
                enabled = false;
                return;
            }
            StartCoroutine(Begin());
        }

        IEnumerator Begin() {
            state = State.Countdown;
            foreach (var r in racers) r.car.controlsEnabled = false;
            for (int i = countdownSeconds; i > 0; i--) { CountdownValue = i; yield return new WaitForSeconds(1f); }
            CountdownValue = 0; state = State.Racing;
            foreach (var r in racers) r.car.controlsEnabled = true;
        }

        void Update() {
            if (state != State.Racing) return;
            RaceTime += Time.deltaTime;
            foreach (var r in racers) { if (!r || !r.car) continue; r.Tick(RaceTime); CheckStuck(r); }
            racers.Sort((a, b) => b.Score.CompareTo(a.Score));
            PlayerPosition = racers.IndexOf(player) + 1;
            if (player && player.Finished) {
                state = State.Finished;
                OnRaceFinished?.Invoke(racers);
            }
        }

        void CheckStuck(RacerProgress r) {
            if (!r || !r.car || !r.path || !r.path.IsValid) return;
            bool flipped = Vector3.Dot(r.car.transform.up, Vector3.up) < 0.2f;
            bool slow = r.car.SpeedKmh < 5f && r.car.input.throttle > 0.5f;
            stuck.TryGetValue(r, out float t);
            t = (flipped || slow) ? t + Time.deltaTime : 0f; stuck[r] = t;
            if (t > resetIfStuckSeconds) {
                int prev = (r.NextIndex - 1 + r.path.Count) % r.path.Count;
                Vector3 a = r.path.Pos(prev), b = r.path.Pos(r.NextIndex);
                r.car.Respawn(a, Quaternion.LookRotation((b - a).normalized, Vector3.up)); stuck[r] = 0;
            }
        }

        public static int RewardForPosition(int pos) => pos == 1 ? 1000 : pos == 2 ? 600 : pos == 3 ? 350 : 150;
    }
}
