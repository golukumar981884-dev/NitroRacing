using UnityEngine;
namespace NitroRacing {
    /// <summary>Ordered racing line. Child transforms = waypoints.</summary>
    public class WaypointPath : MonoBehaviour {
        public Transform[] points;
        [ContextMenu("Collect children")]
        void Collect() { points = new Transform[transform.childCount];
            for (int i = 0; i < points.Length; i++) points[i] = transform.GetChild(i); }
        public int Count => points == null ? 0 : points.Length;
        public bool IsValid => points != null && points.Length >= 2 && System.Array.TrueForAll(points, p => p != null);
        public Vector3 Pos(int i) {
            if (Count == 0) return transform.position;
            return points[((i % Count) + Count) % Count].position;
        }
        void OnDrawGizmos() {
            if (points == null) return; Gizmos.color = Color.cyan;
            for (int i = 0; i < points.Length; i++) {
                if (!points[i]) continue; Gizmos.DrawSphere(points[i].position, 0.8f);
                if (i + 1 < points.Length && points[i+1]) Gizmos.DrawLine(points[i].position, points[i+1].position);
            }
        }
    }
}
