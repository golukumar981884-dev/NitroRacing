using UnityEngine;
namespace NitroRacing {
    /// <summary>Checkpoint progress, laps and finish for one racer.</summary>
    public class RacerProgress : MonoBehaviour {
        public ArcadeVehicle car; public WaypointPath path;
        public string racerName = "Racer"; public bool isPlayer;
        public float checkpointRadius = 18f;
        public int totalLaps = 1;
        public int NextIndex { get; private set; } = 1;
        public int Lap { get; private set; }
        public bool Finished { get; private set; }
        public float FinishTime { get; private set; }
        public float Score { get; private set; }

        void Awake() {
            if (!car) car = GetComponent<ArcadeVehicle>();
            if (!car || !path || !path.IsValid || totalLaps < 1) {
                Debug.LogError($"RacerProgress on {name}: assign a car, a valid path (2+ waypoints), and totalLaps >= 1.", this);
                enabled = false;
            }
        }

        public void Tick(float raceTime) {
            if (Finished || !enabled || !car || !path || !path.IsValid) return;
            Vector3 p = car.transform.position;
            if ((p - path.Pos(NextIndex)).sqrMagnitude < checkpointRadius * checkpointRadius) {
                NextIndex++;
                if (NextIndex >= path.Count) {
                    NextIndex = 0; Lap++;
                    if (Lap >= totalLaps) { Finished = true; FinishTime = raceTime; }
                }
            }
            int prev = (NextIndex - 1 + path.Count) % path.Count;
            float seg = Vector3.Distance(path.Pos(prev), path.Pos(NextIndex));
            float frac = 1f - Mathf.Clamp01(Vector3.Distance(p, path.Pos(NextIndex)) / Mathf.Max(seg, 1f));
            float idx = NextIndex == 0 ? path.Count : NextIndex;
            Score = Lap * path.Count + (idx - 1) + frac;
            if (Finished) Score += 100000f - FinishTime;
        }
        public float Percent => path != null && path.Count > 0 && totalLaps > 0 ? Mathf.Clamp01(Score / (totalLaps * path.Count)) : 0f;
    }
}
