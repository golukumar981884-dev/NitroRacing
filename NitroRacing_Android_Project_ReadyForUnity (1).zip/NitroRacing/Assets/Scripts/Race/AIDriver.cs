using UnityEngine;
namespace NitroRacing {
    /// <summary>
    /// Fair AI: same physics and input channels as the player, no speed cheats.
    /// Looks ahead on the waypoint line, brakes for corners, nitro on straights,
    /// simple avoidance of cars ahead.
    /// </summary>
    [RequireComponent(typeof(ArcadeVehicle), typeof(RacerProgress))]
    public class AIDriver : MonoBehaviour {
        public enum Difficulty { Easy, Medium, Hard }
        public Difficulty difficulty = Difficulty.Medium;
        public float lookAhead = 22f;
        public float avoidRadius = 8f;
        public LayerMask carMask = ~0;
        ArcadeVehicle car; RacerProgress prog;
        float lateralBias, biasTimer;

        void Awake() { car = GetComponent<ArcadeVehicle>(); prog = GetComponent<RacerProgress>(); }
        float Skill => difficulty == Difficulty.Easy ? 0.7f : difficulty == Difficulty.Medium ? 0.88f : 1f;

        void Update() {
            if (!car || !prog || !car.controlsEnabled || !prog.path || !prog.path.IsValid || !car.stats) return;
            var path = prog.path; var i = car.input;
            Vector3 pos = car.transform.position;

            int idx = prog.NextIndex; float acc = 0; Vector3 aim = path.Pos(idx), prev = pos;
            for (int k = 0; k < 6; k++) {
                Vector3 w = path.Pos(idx + k); acc += Vector3.Distance(prev, w); prev = w; aim = w;
                if (acc > lookAhead + car.SpeedKmh * 0.2f) break;
            }

            biasTimer -= Time.deltaTime;
            if (biasTimer <= 0) {
                lateralBias = 0;
                var hits = Physics.OverlapSphere(pos + car.transform.forward * avoidRadius, avoidRadius, carMask);
                foreach (var h in hits) {
                    var other = h.GetComponentInParent<ArcadeVehicle>();
                    if (other && other != car) {
                        Vector3 rel = car.transform.InverseTransformPoint(other.transform.position);
                        lateralBias = rel.x > 0 ? -4f : 4f; break;
                    }
                }
                biasTimer = 0.25f;
            }
            aim += car.transform.right * lateralBias;

            Vector3 local = car.transform.InverseTransformPoint(aim);
            float angle = Mathf.Atan2(local.x, local.z) * Mathf.Rad2Deg;
            i.steer = Mathf.Clamp(angle / 35f, -1f, 1f);

            float sharp = Mathf.Abs(angle) / 90f;
            float targetSpeed = Mathf.Lerp(car.stats.TopSpeed * Skill, 90f, Mathf.Clamp01(sharp * 1.6f));
            float spd = car.SpeedKmh;
            i.throttle = spd < targetSpeed ? 1f : 0f;
            i.brake = spd > targetSpeed + 25f ? Mathf.Clamp01((spd - targetSpeed) / 80f) : 0f;
            i.nitro = Mathf.Abs(angle) < 6f && car.Nitro.Normalized > 0.3f && difficulty != Difficulty.Easy;
            i.drift = Mathf.Abs(angle) > 28f && spd > 110f && difficulty == Difficulty.Hard;
        }
    }
}
