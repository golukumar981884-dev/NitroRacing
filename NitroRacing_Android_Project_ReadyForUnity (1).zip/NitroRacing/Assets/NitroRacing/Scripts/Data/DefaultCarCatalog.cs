using System.Collections.Generic;
using UnityEngine;
using NitroRacing.Data;

namespace NitroRacing.Data
{
    // Runtime fictional catalog: 50 entries. Replace visuals with licensed/original 3D models.
    public static class DefaultCarCatalog
    {
        private static readonly string[] Prefixes = {
            "Apex", "Vortex", "Tempest", "Falcon", "Nova", "Phantom", "Raptor", "Zenith",
            "Velocity", "Eclipse"
        };
        private static readonly string[] Suffixes = { "GT", "R", "XR", "S", "RS" };

        public static CarDefinition[] Create()
        {
            var list = new List<CarDefinition>(50);
            for (int i = 0; i < 50; i++)
            {
                int tier = i / 10;
                list.Add(new CarDefinition {
                    id = "NR_" + (i + 1).ToString("00"),
                    displayName = Prefixes[i % Prefixes.Length] + " " + Suffixes[(i / 2) % Suffixes.Length] + " " + (100 + i),
                    carClass = (CarClass)tier,
                    topSpeedKph = 220 + tier * 42 + (i % 5) * 5,
                    acceleration = 1.2f + tier * 0.55f + (i % 3) * 0.08f,
                    handling = 1.4f + (i % 7) * 0.12f + tier * 0.15f,
                    nitroCapacity = 55 + tier * 8,
                    unlockLevel = i * 2,
                    price = 0,
                    paint = Color.HSVToRGB((i * 0.6180339f) % 1f, 0.72f, 0.95f)
                });
            }
            return list.ToArray();
        }
    }
}
