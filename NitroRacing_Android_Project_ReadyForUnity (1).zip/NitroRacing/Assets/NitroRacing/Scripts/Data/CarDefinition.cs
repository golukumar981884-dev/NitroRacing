using System;
using UnityEngine;

namespace NitroRacing.Data
{
    public enum CarClass { D, C, B, A, S }

    [Serializable]
    public class CarDefinition
    {
        public string id;
        public string displayName;
        public CarClass carClass;
        [Range(100f, 450f)] public float topSpeedKph;
        [Range(0.1f, 5f)] public float acceleration;
        [Range(0.1f, 5f)] public float handling;
        [Range(0f, 100f)] public float nitroCapacity;
        public int unlockLevel;
        public int price;
        public Color paint = Color.blue;
    }

    [CreateAssetMenu(menuName = "Nitro Racing/Car Catalog")]
    public class CarCatalog : ScriptableObject
    {
        public CarDefinition[] cars;

        public CarDefinition GetByIndex(int index)
        {
            if (cars == null || cars.Length == 0) return null;
            return cars[Mathf.Clamp(index, 0, cars.Length - 1)];
        }
    }
}
